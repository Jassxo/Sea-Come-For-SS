package com.seass.listeners;

import com.seass.SeaSS;
import com.seass.utils.ColorUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.*;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

public class PlayerListener implements Listener {

    private final SeaSS plugin;

    public PlayerListener(SeaSS plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (plugin.getFreezeManager().isFrozen(player.getUniqueId())) {
            if (plugin.getConfigManager().getSettings().getBoolean("freeze.block-movement")) {
                if (event.getFrom().getX() != event.getTo().getX() || event.getFrom().getZ() != event.getTo().getZ()) {
                    event.setTo(event.getFrom());
                }
            }
        }
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (plugin.getFreezeManager().isFrozen(player.getUniqueId())) {
            if (plugin.getConfigManager().getSettings().getBoolean("freeze.block-commands")) {
                String cmd = event.getMessage().split(" ")[0].toLowerCase();
                List<String> allowedCmds = plugin.getConfigManager().getSettings().getStringList("freeze.allowed-commands");
                if (!allowedCmds.contains(cmd)) {
                    event.setCancelled(true);
                    player.sendMessage(ColorUtils.format("&cCommands are blocked while frozen."));
                }
            }
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (plugin.getFreezeManager().isFrozen(player.getUniqueId())) {
            if (plugin.getConfigManager().getSettings().getBoolean("freeze.block-drop")) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (plugin.getFreezeManager().isFrozen(player.getUniqueId())) {
            if (plugin.getConfigManager().getSettings().getBoolean("freeze.block-inventory")) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getIntegrationManager().handleLogout(player);
        plugin.getFreezeManager().unfreezePlayer(player);
        // We do not end session automatically in case of accidental crash,
        // but the staff can decide to end it or punishment will be handled by integration.
    }
}
