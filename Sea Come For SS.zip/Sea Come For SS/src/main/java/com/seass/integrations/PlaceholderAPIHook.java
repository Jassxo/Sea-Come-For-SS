package com.seass.integrations;

import com.seass.SeaSS;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.TimeUnit;

public class PlaceholderAPIHook extends PlaceholderExpansion {

    private final SeaSS plugin;

    public PlaceholderAPIHook(SeaSS plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "seass";
    }

    @Override
    public @NotNull String getAuthor() {
        return "SeaSS";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";

        if (params.equalsIgnoreCase("in_ss")) {
            return String.valueOf(plugin.getScreenShareManager().isInSS(player.getUniqueId()));
        }

        if (params.equalsIgnoreCase("staff")) {
            Player staff = plugin.getScreenShareManager().getStaff(player.getUniqueId());
            return staff != null ? staff.getName() : "None";
        }

        if (params.equalsIgnoreCase("time")) {
            long startTime = plugin.getScreenShareManager().getDuration(player.getUniqueId());
            if (startTime == 0) return "0s";
            long seconds = (System.currentTimeMillis() - startTime) / 1000;
            return formatTime(seconds);
        }

        return null;
    }

    private String formatTime(long seconds) {
        long mm = seconds / 60;
        long ss = seconds % 60;
        return String.format("%02d:%02d", mm, ss);
    }
}
