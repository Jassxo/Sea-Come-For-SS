package com.seass;

import com.seass.commands.SSCommand;
import com.seass.integrations.PlaceholderAPIHook;
import com.seass.listeners.PlayerListener;
import com.seass.managers.ConfigManager;
import com.seass.managers.FreezeManager;
import com.seass.managers.IntegrationManager;
import com.seass.managers.ScreenShareManager;
import org.bukkit.plugin.java.JavaPlugin;

public class SeaSS extends JavaPlugin {

    private static SeaSS instance;

    private ConfigManager configManager;
    private ScreenShareManager screenShareManager;
    private FreezeManager freezeManager;
    private IntegrationManager integrationManager;

    @Override
    public void onEnable() {
        instance = this;

        // Load managers
        this.configManager = new ConfigManager(this);
        this.freezeManager = new FreezeManager(this);
        this.screenShareManager = new ScreenShareManager(this);
        this.integrationManager = new IntegrationManager(this);

        // Register commands
        if (getCommand("ss") != null) {
            SSCommand ssCommand = new SSCommand(this);
            getCommand("ss").setExecutor(ssCommand);
            getCommand("ss").setTabCompleter(ssCommand);
        }

        // Register listeners
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);

        // Register Placeholders
        if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new PlaceholderAPIHook(this).register();
        }

        getLogger().info("SeaSS has been enabled successfully!");
    }

    @Override
    public void onDisable() {
        getLogger().info("SeaSS has been disabled!");
    }

    public static SeaSS getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public ScreenShareManager getScreenShareManager() {
        return screenShareManager;
    }

    public FreezeManager getFreezeManager() {
        return freezeManager;
    }

    public IntegrationManager getIntegrationManager() {
        return integrationManager;
    }
}
