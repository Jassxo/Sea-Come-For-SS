package com.seass.managers;

import com.seass.SeaSS;
import com.seass.utils.ColorUtils;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class FreezeManager {

    private final SeaSS plugin;
    private final Set<UUID> frozenPlayers = new HashSet<>();

    public FreezeManager(SeaSS plugin) {
        this.plugin = plugin;
    }

    public void freezePlayer(Player player) {
        frozenPlayers.add(player.getUniqueId());
        player.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.ss-frozen")));
    }

    public void unfreezePlayer(Player player) {
        if (frozenPlayers.remove(player.getUniqueId())) {
            player.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.ss-unfrozen")));
        }
    }

    public void unfreezePlayerQuietly(UUID uuid) {
        frozenPlayers.remove(uuid);
    }

    public boolean isFrozen(UUID uuid) {
        return frozenPlayers.contains(uuid);
    }

    public void toggleFreeze(Player player) {
        if (isFrozen(player.getUniqueId())) {
            unfreezePlayer(player);
        } else {
            freezePlayer(player);
        }
    }
}
