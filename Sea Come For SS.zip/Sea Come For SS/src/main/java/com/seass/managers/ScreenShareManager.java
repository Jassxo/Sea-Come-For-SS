package com.seass.managers;

import com.seass.SeaSS;
import com.seass.utils.ColorUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ScreenShareManager {

    private final SeaSS plugin;
    private final Map<UUID, UUID> activeSS = new HashMap<>(); // playerID -> staffID
    private final Map<UUID, Long> startTime = new HashMap<>();

    public ScreenShareManager(SeaSS plugin) {
        this.plugin = plugin;
        startActionBarReminder();
    }

    public void startSS(Player player, Player staff) {
        if (activeSS.containsKey(player.getUniqueId())) return;

        activeSS.put(player.getUniqueId(), staff.getUniqueId());
        startTime.put(player.getUniqueId(), System.currentTimeMillis());

        // Send Title/Subtitle
        String titleStr = plugin.getConfigManager().getMessages().getString("messages.ss-called-title");
        String subtitleStr = plugin.getConfigManager().getMessages().getString("messages.ss-called-subtitle");

        Title title = Title.title(
                ColorUtils.format(titleStr),
                ColorUtils.format(subtitleStr),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofMillis(500))
        );
        player.showTitle(title);

        // Notify
        player.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.ss-started-player")));
        staff.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.ss-started-staff")
                .replace("{player}", player.getName())));

        // Check if freeze is enabled on call
        if (plugin.getConfigManager().getSettings().getBoolean("freeze.enabled-on-call")) {
            plugin.getFreezeManager().freezePlayer(player);
        }
    }

    public void endSS(Player player, Player staff) {
        activeSS.remove(player.getUniqueId());
        startTime.remove(player.getUniqueId());
        plugin.getFreezeManager().unfreezePlayer(player);

        player.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.ss-cancelled-player")));
        staff.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.ss-cancelled-staff")
                .replace("{player}", player.getName())));
    }

    public boolean isInSS(UUID playerUUID) {
        return activeSS.containsKey(playerUUID);
    }

    public Player getStaff(UUID playerUUID) {
        UUID staffUUID = activeSS.get(playerUUID);
        return staffUUID == null ? null : Bukkit.getPlayer(staffUUID);
    }

    public Map<UUID, UUID> getActiveSS() {
        return activeSS;
    }

    public long getDuration(UUID playerUUID) {
        return startTime.getOrDefault(playerUUID, 0L);
    }

    private void startActionBarReminder() {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (plugin.getConfigManager() == null || plugin.getConfigManager().getSettings() == null) return;
                
                boolean enabled = plugin.getConfigManager().getSettings().getBoolean("notifications.action-bar.enabled", true);
                if (!enabled) return;

                String barText = plugin.getConfigManager().getMessages().getString("messages.action-bar-reminder");
                Component component = ColorUtils.format(barText);

                for (UUID uuid : activeSS.keySet()) {
                    Player p = Bukkit.getPlayer(uuid);
                    if (p != null && p.isOnline()) {
                        p.sendActionBar(component);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 100L); // Run every 5 seconds (100 ticks)
    }
}
