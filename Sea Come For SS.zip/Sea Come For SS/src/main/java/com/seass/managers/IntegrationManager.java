package com.seass.managers;

import com.seass.SeaSS;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.UUID;

public class IntegrationManager {

    private final SeaSS plugin;

    public IntegrationManager(SeaSS plugin) {
        this.plugin = plugin;
    }

    public void handleLogout(Player player) {
        UUID uuid = player.getUniqueId();
        if (!plugin.getScreenShareManager().isInSS(uuid)) return;

        if (plugin.getConfigManager().getSettings().getBoolean("punishments.logout-during-ss.enabled")) {
            String type = plugin.getConfigManager().getSettings().getString("punishments.logout-during-ss.type", "TEMPBAN");
            String duration = plugin.getConfigManager().getSettings().getString("punishments.logout-during-ss.duration", "7d");
            String reason = plugin.getConfigManager().getSettings().getString("punishments.logout-during-ss.reason", "Logged out during SS");

            String command;
            if (type.equalsIgnoreCase("TEMPBAN")) {
                command = "tempban " + player.getName() + " " + duration + " " + reason;
            } else if (type.equalsIgnoreCase("BAN")) {
                command = "ban " + player.getName() + " " + reason;
            } else {
                command = "kick " + player.getName() + " " + reason;
            }

            // Dispatch command console side
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);

            // END SS SESSION so they aren't still in SS when they return (unbanned)
            plugin.getScreenShareManager().getActiveSS().remove(uuid);
            // Also ensure they are unfrozen in the manager state
            plugin.getFreezeManager().unfreezePlayerQuietly(uuid);
        }
    }
}
