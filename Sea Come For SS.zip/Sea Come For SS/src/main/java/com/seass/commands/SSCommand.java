package com.seass.commands;

import com.seass.SeaSS;
import com.seass.utils.ColorUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class SSCommand implements CommandExecutor, TabCompleter {

    private final SeaSS plugin;

    public SSCommand(SeaSS plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("seass.use")) {
            sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.no-permission")));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String subCommand = args[0].toLowerCase();

        switch (subCommand) {
            case "reload":
                handleReload(sender);
                break;
            case "list":
                sendList(sender);
                break;
            case "freeze":
                if (args.length < 2) return false;
                handleFreeze(sender, args[1]);
                break;
            case "unfreeze":
                if (args.length < 2) return false;
                handleUnfreeze(sender, args[1]);
                break;
            case "tp":
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Only players can use this command.");
                    return true;
                }
                if (args.length < 2) return false;
                handleTP(player, args[1]);
                break;
            case "cancel":
                if (args.length < 2) return false;
                handleCancel(sender, args[1]);
                break;
            default:
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Only players can call an SS.");
                    return true;
                }
                handleSS(player, subCommand);
                break;
        }

        return true;
    }

    private void handleReload(CommandSender sender) {
        if (!sender.hasPermission("seass.admin")) {
            sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.no-permission")));
            return;
        }
        plugin.getConfigManager().reload();
        sender.sendMessage(ColorUtils.format("&aSeaSS configurations reloaded successfully!"));
    }

    private void handleSS(Player staff, String targetName) {
        Player target = Bukkit.getPlayer(targetName);
        if (target == null) {
            staff.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.player-not-found")));
            return;
        }
        if (plugin.getScreenShareManager().isInSS(target.getUniqueId())) {
            staff.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.already-in-ss")));
            return;
        }
        plugin.getScreenShareManager().startSS(target, staff);
    }

    private void handleFreeze(CommandSender sender, String targetName) {
        if (!sender.hasPermission("seass.freeze")) {
            sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.no-permission")));
            return;
        }
        Player target = Bukkit.getPlayer(targetName);
        if (target == null) {
            sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.player-not-found")));
            return;
        }
        plugin.getFreezeManager().freezePlayer(target);
        sender.sendMessage(ColorUtils.format("&aYou froze " + target.getName()));
    }

    private void handleUnfreeze(CommandSender sender, String targetName) {
        if (!sender.hasPermission("seass.freeze")) {
            sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.no-permission")));
            return;
        }
        Player target = Bukkit.getPlayer(targetName);
        if (target == null) {
            sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.player-not-found")));
            return;
        }
        plugin.getFreezeManager().unfreezePlayer(target);
        sender.sendMessage(ColorUtils.format("&aYou unfroze " + target.getName()));
    }

    private void handleTP(Player staff, String targetName) {
        Player target = Bukkit.getPlayer(targetName);
        if (target == null) {
            staff.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.player-not-found")));
            return;
        }
        staff.teleport(target.getLocation());
        staff.sendMessage(ColorUtils.format("&aTeleported to " + target.getName()));
    }

    private void handleCancel(CommandSender sender, String targetName) {
        Player target = Bukkit.getPlayer(targetName);
        if (target == null) {
            sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.player-not-found")));
            return;
        }
        if (!plugin.getScreenShareManager().isInSS(target.getUniqueId())) {
            sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.not-in-ss")));
            return;
        }
        
        Player staff = (sender instanceof Player p) ? p : null;
        plugin.getScreenShareManager().endSS(target, staff);
    }

    private void sendList(CommandSender sender) {
        sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.ss-list-header")));
        Map<UUID, UUID> activeSS = plugin.getScreenShareManager().getActiveSS();
        if (activeSS.isEmpty()) {
            sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.ss-list-empty")));
            return;
        }
        activeSS.forEach((pID, sID) -> {
            Player p = Bukkit.getPlayer(pID);
            Player s = Bukkit.getPlayer(sID);
            sender.sendMessage(ColorUtils.format(plugin.getConfigManager().getMessages().getString("messages.ss-list-format")
                    .replace("{player}", (p != null ? p.getName() : "Unknown"))
                    .replace("{staff}", (s != null ? s.getName() : "Unknown"))));
        });
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ColorUtils.format("&b&lSeaSS Commands:"));
        sender.sendMessage(ColorUtils.format("&7/ss <player> &f- Call for Screen Share"));
        sender.sendMessage(ColorUtils.format("&7/ss reload &f- Reload configurations"));
        sender.sendMessage(ColorUtils.format("&7/ss list &f- List active SS sessions"));
        sender.sendMessage(ColorUtils.format("&7/ss freeze <player> &f- Freeze player"));
        sender.sendMessage(ColorUtils.format("&7/ss unfreeze <player> &f- Unfreeze player"));
        sender.sendMessage(ColorUtils.format("&7/ss tp <player> &f- Teleport to player"));
        sender.sendMessage(ColorUtils.format("&7/ss cancel <player> &f- End SS session"));
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            completions.add("reload");
            completions.add("list");
            completions.add("freeze");
            completions.add("unfreeze");
            completions.add("tp");
            completions.add("cancel");
            for (Player p : Bukkit.getOnlinePlayers()) {
                completions.add(p.getName());
            }
        } else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("freeze") || args[0].equalsIgnoreCase("unfreeze") ||
                args[0].equalsIgnoreCase("tp") || args[0].equalsIgnoreCase("cancel")) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    completions.add(p.getName());
                }
            }
        }
        return completions.stream().filter(s -> s.toLowerCase().startsWith(args[args.length - 1].toLowerCase())).collect(Collectors.toList());
    }
}
